const jwt = require('jsonwebtoken');

const adminAuthCheck = (req, res, next) => {
    const token = req.headers['auth'];
    console.log("[ADMIN TOKEN]",token)

    if (!token) {
        return res.status(403).json({ message: 'No token provided.' });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(500).json({ message: 'Failed to authenticate token.' });
        }

        if (decoded.role !== 'admin') {
            return res.status(403).json({ message: 'You are not authorized to access this resource.' });
        }

        req.user = decoded;
        next();
    });
};

module.exports = adminAuthCheck;