const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const authRouter = require("./routes/user_auth");
const adminAuthRouter = require("./routes/admin_auth");
const itemRouter = require("./routes/item");
const bcrypt = require("bcrypt");
const { create_payment_link, payment_success, payment_fail, payment_cancel } = require("./lib/reserve");
const reserveRouter = require("./routes/reserve");
const AdminModel = require("./models/adminMode");
const uploadRouter = require("./routes/uploadImage");
const upload = require("./lib/upload");
require("dotenv").config("./env");
app.use("/uploads", express.static("uploads"));
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

mongoose
  .connect(process.env.DB)
  .then((res) => {
    AdminModel.findOne().then(async(admin) => {
      if (!admin) {
        const admin = new AdminModel({
          email: "admin@booker.com",
          password: await bcrypt.hash("admin", 10),
        });
        admin.save();
      }
    });
    console.log("database connected");
  })
  .catch((err) => {
    console.log("failed to connect database");
    console.log(err);
  });



app.use("/auth", authRouter);
app.use("/admin/auth", adminAuthRouter)
app.use("/item", itemRouter)
app.use("/reserve", reserveRouter)
app.post("/payment",async (req, res) => {
  const url = await create_payment_link(req.body.price);
  res.json({ url });
})
app.post("/payment/success", payment_success);
app.post("/payment/fail", payment_fail);
app.post("/payment/cancel", payment_cancel);
app.use("/upload", uploadRouter)
app.get("/", (req, res) => {
  res.send("server is running good");
});



app.listen(8000, () => {
  console.log("server is running on port 8000");
});
