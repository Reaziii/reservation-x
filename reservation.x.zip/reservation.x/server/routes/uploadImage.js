const express = require("express");
const upload = require("../lib/upload");
const uploadImage = require("../lib/uploadImage");
const uploadRouter = express.Router();


uploadRouter.post("/", upload.single("file"), uploadImage)

module.exports = uploadRouter;