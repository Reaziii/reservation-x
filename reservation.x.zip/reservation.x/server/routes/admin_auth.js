const { userRegistrationApi, userLogin } = require("../lib/admin_auth");
const adminAuthRouter = require("express").Router();
adminAuthRouter.post("/registration", userRegistrationApi);
adminAuthRouter.post("/login", userLogin);
module.exports = adminAuthRouter;
