const express = require("express");
const reserveRouter = express.Router();
const { create_reserve, delete_reserve, get_my_bookings } = require("../lib/reserve");
const authCheck = require("../middleware/authCheck");
const addAuth = require("../middleware/addAuth");

reserveRouter.post("/", authCheck, create_reserve);
reserveRouter.delete("/:itemid", authCheck, delete_reserve);
reserveRouter.get("/", addAuth, get_my_bookings)
module.exports = reserveRouter;