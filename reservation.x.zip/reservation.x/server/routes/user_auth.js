const { userRegistrationApi, userLogin } = require("../lib/user_auth");
const authRouter = require("express").Router();
authRouter.post("/registration", userRegistrationApi);
authRouter.post("/login", userLogin);
module.exports = authRouter;
