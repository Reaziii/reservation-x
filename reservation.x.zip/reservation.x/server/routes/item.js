const { createItem, deleteItem, updateItem, getItems, getItem } = require('../lib/item')
const adminAuthCheck = require('../middleware/adminAuthCheck')

const itemRouter = require('express').Router()

itemRouter.post("/", adminAuthCheck ,createItem)
itemRouter.delete("/",adminAuthCheck, deleteItem)
itemRouter.put("/", adminAuthCheck, updateItem)
itemRouter.get("/", getItems)
itemRouter.get("/:id", getItem)

module.exports = itemRouter