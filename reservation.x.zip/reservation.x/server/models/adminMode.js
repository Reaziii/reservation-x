const mongoose = require("mongoose")

const schema = mongoose.Schema({
    phone : String,
    email : String,
    full_name : String,
    password : String
})

const AdminModel = mongoose.model("admins", schema)
module.exports = AdminModel