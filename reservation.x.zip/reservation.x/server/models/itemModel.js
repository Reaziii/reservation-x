const mongoose = require('mongoose')

const schema = mongoose.Schema({
    address : String,
    photo : String,
    name : String,
    description : String,
    price : Number,
    type : String

})

const itemModel = mongoose.model("items", schema)
module.exports = itemModel