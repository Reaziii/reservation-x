const mongoose = require("mongoose")

const schema = mongoose.Schema({
    phone : String,
    email : String,
    full_name : String,
    password : String
})

const userModel = mongoose.model("users", schema)
module.exports = userModel