const mongoose = require('mongoose')

const schema = mongoose.Schema({
    userid : String,
    itemid : String,
    date : Date,
    paid : {
        type : Boolean,
        default : false
    },
    tid : String,
})

const reserveModel = mongoose.model("reserves", schema)
module.exports = reserveModel