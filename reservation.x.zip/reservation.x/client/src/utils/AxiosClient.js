import axios from "axios";




const Client = axios.create({
  baseURL: "http://localhost:8000",
  headers: {
    auth: localStorage.getItem("jwttoken"),
  },
});

export default Client;