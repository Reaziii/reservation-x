import {
  createBrowserRouter,
  RouterProvider,
  Route,
  Link,
} from "react-router-dom";
import Home from "./routes/Home/Home";
import Login from "./routes/login/Login";
import Registration from "./routes/Registration/Registration";
import Item from "./routes/Item/Item";
import PrivateRoute from "./routes/PrivateRoute";
import AdminItems from "./routes/AdminItems/AdminItems";
import PaymentSuccess from "./routes/PaymentSucces/PaymentSuccess";
import AdminLogin from "./routes/AdminLogin/AdminLogin";
import MyBookings from "./routes/MyBookings/MyBookings";
import PaymentFailed from "./routes/PaymentFailed/PaymentFailed";

export default createBrowserRouter([
  {
    path: "/",
    element: <PrivateRoute component={Home} />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/registration",
    element: <Registration />,
  },
  {
    path: "/item/:id",
    element: <Item />,
  },
  {
    path: "/admin/items",
    element: <AdminItems />,
  },
  {
    path: "/payment/success",
    element: <PaymentSuccess />,
  },
  {
    path: "/payment/fail",
    element: <PaymentFailed />,
  },
  {
    path: "admin/login",
    element: <AdminLogin />,
  },
  {
    path: "/my-bookings",
    element: <PrivateRoute component={MyBookings} />,
  },
]);
