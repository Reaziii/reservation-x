import React from "react";
import "./Home.css"; // Assuming you will add some CSS for styling
import Header from "../../components/Header/Header";
import { useNavigate } from "react-router-dom";

const truncateDescription = (description) => {
  return description.length > 50
    ? description.substring(0, 50) + "..."
    : description;
};

const Home = () => {
  const [items, setItems] = React.useState([]);
  const fetchItems = () => {
    fetch("http://localhost:8000/item")
      .then((response) => response.json())
      .then((data) => {
        setItems(data.data);
      })
      .catch((error) => {
        console.error("Error fetching items:", error);
      });
  };
  React.useEffect(() => {
    fetchItems();
  }, []);
  const navigate = useNavigate()
  const handleReserve = (item) => {
    alert(`Reserved ${item.name}`);
  };

  return (
    <>
      <Header />
      <div className="home-container">
        {items.map((item) => (
          <div key={item.id} className="card">
            <h2>{item.name}</h2>
            <p>Location: {item.location}</p>
            <p>Price: {item.price}</p>
            <p>Description: {truncateDescription(item.description)}</p>
            <button onClick={() => navigate(`/item/${item._id}`)}>Reserve Now</button>
          </div>
        ))}
      </div>
    </>
  );
};

export default Home;
