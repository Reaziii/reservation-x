import Header from "../../components/Header/Header";
import Client from "../../utils/AxiosClient";
import "./MyBookings.css";
import React, { useState, useEffect } from "react";

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    // Fetch bookings from an API or other source
    // This is just a placeholder example
    Client.get("/reserve")
      .then((data) => {
        console.log(data.data.items);
        setBookings([...data.data.items]);
      })
      .catch((error) => console.error("Error fetching bookings:", error));
  }, []);

  const handleDelete = (id) => {
    Client.delete(`/reserve/${id}`)
      .then((response) => {
        if (response.data.success)
          setBookings([...bookings.filter((booking) => booking._id !== id)]);
      })
      .catch((error) => console.error("Error deleting booking:", error));
  };

  return (
    <>
      <Header />
      <div className="my-bookings">
        <h1 className="my-bookings__title">My Bookings</h1>
        <table className="my-bookings__table">
          <thead>
            <tr>
              <th className="my-bookings__header">Name</th>
              <th className="my-bookings__header">Description</th>
              <th className="my-bookings__header">Price</th>
              <th className="my-bookings__header">Date</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((booking) => (
              <tr key={booking.id} className="my-bookings__row">
                <td className="my-bookings__cell">{booking.name}</td>
                <td className="my-bookings__cell">
                  {booking.description?.length > 20
                    ? `${booking.description.substring(0, 20)}...`
                    : booking.description}
                </td>
                <td className="my-bookings__cell">{booking.price}</td>
                <td className="my-bookings__cell">{booking.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default MyBookings;
