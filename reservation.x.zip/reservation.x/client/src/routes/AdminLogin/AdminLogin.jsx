import React, { useState } from 'react';
import Header from '../../components/Header/Header';
import './Login.css';
import { Link } from 'react-router-dom';
import axios from 'axios';

const AdminLogin = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/admin/auth/login", { email, password }).then(resp => {
            if (resp.data.success) {
                localStorage.setItem("admintoken", resp.data.token);

                window.location.href = "/";
            } else {
                alert(resp.data.msg);
            }
        }
        );
    };

    return (
       <>
       <Header/>
        <div className="login-container">
            <form className="login-form" onSubmit={handleSubmit}>
                <h2>Login</h2>
                <div className="form-group">
                    <label htmlFor="email">Email Address</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Login</button>
               

                <div className="register-link">
                    <p>Don't have an account? <Link to="/registration">Register here</Link></p>
                </div>


            </form>
        </div>
       </>
    );
};

export default AdminLogin;