import React, { useState } from 'react';
import './Registration.css';
import Header from '../../components/Header/Header';
import { Link } from 'react-router-dom';
import axios from 'axios';
const Registration = () => {
    const [formData, setFormData] = useState({
        full_name: '',
        email: '',
        password: '',
        phone: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle form submission logic here
        axios.post("http://localhost:8000/auth/registration", formData).then(resp=>{
            if(resp.success){
                alert("Registration successful");
            }
            else{
                alert(resp.data.msg)
            }
        })
    };

    return (
        <>
        <Header/>
        <div className="registration-container">
            <h2>Register</h2>
            <form onSubmit={handleSubmit} className="registration-form">
                <div className="form-group">
                    <label htmlFor="full_name">Full Name</label>
                    <input
                        type="text"
                        id="full_name"
                        name="full_name"
                        value={formData.full_name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="phone">Phone</label>
                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit" className="submit-button">Register</button>

                <div className="register-link">
                    <p>Already have an account? <Link to="/login">Login now</Link></p>
                </div>

            </form>
        </div>
        </>
    );
};

export default Registration;