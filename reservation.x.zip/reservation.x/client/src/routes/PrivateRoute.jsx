import React from 'react';
import { Route, useNavigate, Redirect } from 'react-router-dom';

const PrivateRoute = ({ component: Component, ...rest }) => {
    const isAuthenticated = () => {
        const token = localStorage.getItem('jwttoken') || localStorage.getItem('admintoken');
        return token !== null;
    };
    if (!isAuthenticated()) {
        return <RedirectToLogin/>
    }
    return (
        <Component/>
    );
};

const RedirectToLogin = () => {
   
    return window.location.href = "/login";
}

export default PrivateRoute;