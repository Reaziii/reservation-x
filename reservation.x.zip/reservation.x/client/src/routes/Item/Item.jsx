import React, { useState, useEffect } from "react";
import "./Item.css";
import Header from "../../components/Header/Header";
import Client from "../../utils/AxiosClient";
import { useParams } from "react-router-dom";
import axios from "axios";
const Item = () => {
  const [reserveDate, setReserveDate] = useState("");
  const { id } = useParams();
  const [itemDetails, setItemDetails] = useState({
    address: "",
    name: "",
    description: "",
    price: "",
    type: "",
    photo: "",
  });

  useEffect(() => {
    axios
      .get(`http://localhost:8000/item/${id}`)
      .then((response) => {
        if (response.data.success) {
          setItemDetails(response.data.item);
        } else {
        }
      })
      .catch((error) => {
        console.error("There was an error fetching the item details!", error);
      });
  }, [id]);

  const reserveItem = () => {
    if (localStorage.getItem("jwttoken") === null) {
      window.location.href = "/login";
      return;
    }
    Client.post("/reserve", {
      itemid: id,
      date: new Date(reserveDate),
    }).then((resp) => {
      if (resp.data.success) {
        window.location.href = resp.data.GatewayPageURL;
      } else {
        alert(resp.data.msg);
      }
    });
  };
  const handleReserve = () => {
    alert(`Item reserved for ${reserveDate}`);
  };

  return (
    <>
      <Header />
      <div style={{ padding: "20px", maxWidth: "600px", margin: "0 auto" }}>
        <h1>{itemDetails.name}</h1>
        <img
          src={`http://localhost:8000/${itemDetails.photo}`}
          alt="Item"
          style={{ width: "100%", height: "auto" }}
        />
        <p>{itemDetails.description}</p>
        <h2>{itemDetails.price} TK</h2>
        <div>
          <label>
            Address:
            <h1>{itemDetails.address}</h1>
          </label>
        </div>
        <div>
          <label>
            Reserve Date:
            <input
              type="date"
              value={reserveDate}
              onChange={(e) => setReserveDate(e.target.value)}
              style={{ marginLeft: "10px" }}
            />
          </label>
        </div>
        <button
          onClick={reserveItem}
          style={{ marginTop: "20px", padding: "10px 20px", fontSize: "16px" }}
        >
          Reserve
        </button>
      </div>
    </>
  );
};

export default Item;
