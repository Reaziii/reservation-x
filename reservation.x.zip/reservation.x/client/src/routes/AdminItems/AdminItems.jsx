import React, { useState, useEffect } from "react";
import "./AdminItems.css";
import { Link } from "react-router-dom";
import axios from "axios";

const AdminItems = () => {
    const [item, setItem] = useState({
        name: "",
        description: "",
        price: "",
        type: "vehicle",
        address: "",
    });
    const [image, setImage] = useState(null);

    const [items, setItems] = useState([
        {
            id: 1,
            name: "Car",
            description: "A nice car",
            price: 10000,
            type: "vehicle",
        },
        {
            id: 2,
            name: "Banquet Hall",
            description: "Spacious hall",
            price: 5000,
            type: "hall",
        },
        {
            id: 3,
            name: "Hotel Room",
            description: "Luxury room",
            price: 200,
            type: "hotel",
        },
    ]);

    const fetchItems = () => {
        fetch("http://localhost:8000/item")
            .then((response) => response.json())
            .then((data) => {
                setItems(data.data);
            })
            .catch((error) => {
                console.error("Error fetching items:", error);
            });
    };

    useEffect(() => {
        fetchItems();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setItem({
            ...item,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!image) {
            return alert("Please select an image");
        }
        const formdata = new FormData();
        formdata.append("file", image);
        const uploadedImage = await axios.post("http://localhost:8000/upload", formdata, {
            headers: {
                "Content-Type": "multipart/form-data",
                "auth": localStorage.getItem("admintoken"),
            },
        });
        if (!uploadedImage.data.success) {
            return alert("Failed to upload image");
        }
      

        fetch("http://localhost:8000/item", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "auth": localStorage.getItem("admintoken"),

            },
            body: JSON.stringify({...item, image: uploadedImage.data.path}),
        })
            .then((response) => response.json())
            .then((data) => {
                fetchItems()
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    };

    const handleDelete = (id) => {
        fetch(`http://localhost:8000/item`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "auth": localStorage.getItem("admintoken"),
            },
            body: JSON.stringify({ _id: id }),
        })
            .then((response) => response.json())
            .then((data) => {
                if(data.success){
                    setItems(items.filter((item) => item._id !== id));
                }
            })
            .catch((error) => {
                console.error("Error deleting item:", error);
            });
    };

    return (
        <div className="admin-items">
            <h1 className="admin-items__title">Create Item</h1>
            <form className="admin-items__form" onSubmit={handleSubmit}>
                <div className="admin-items__form-group">
                    <label className="admin-items__label">Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={item.name}
                        onChange={handleChange}
                        required
                        className="admin-items__input"
                    />
                </div>

                <div className="admin-items__form-group">
                    <label className="admin-items__label">Image:</label>
                    <input
                        type="file"
                        name="image"
                        onChange={(e) => {
                            setImage(e.target.files[0]);
                        }}
                        className="admin-items__input"
                    />
                </div>

                <div className="admin-items__form-group">
                    <label className="admin-items__label">Description:</label>
                    <textarea
                        name="description"
                        value={item.description}
                        onChange={handleChange}
                        required
                        className="admin-items__textarea"
                    />
                </div>
                <div className="admin-items__form-group">
                    <label className="admin-items__label">Price:</label>
                    <input
                        type="number"
                        name="price"
                        value={item.price}
                        onChange={handleChange}
                        required
                        className="admin-items__input"
                    />
                </div>
                <div className="admin-items__form-group">
                    <label className="admin-items__label">Location:</label>
                    <input
                        type="text"
                        name="address"
                        value={item.address}
                        onChange={handleChange}
                        required
                        className="admin-items__input"
                    />
                </div>
                <div className="admin-items__form-group">
                    <label className="admin-items__label">Type:</label>
                    <select
                        name="type"
                        value={item.type}
                        onChange={handleChange}
                        required
                        className="admin-items__select"
                    >
                        <option value="vehicle">Vehicle</option>
                        <option value="hall">Hall</option>
                        <option value="hotel">Hotel</option>
                    </select>
                </div>
                <button type="submit" className="admin-items__button">
                    Create Item
                </button>
            </form>

            <h2 className="admin-items__subtitle">Old Items</h2>
            <div className="admin-items__list">
                {items.map((oldItem) => (
                    <div key={oldItem.id} className="admin-items__item">
                        <Link to={`/item/${oldItem._id}`} className="admin-items__item-name">
                            <h3 className="admin-items__item-title">{oldItem.name}</h3>
                        </Link>
                        <p className="admin-items__item-description">{oldItem.description}</p>
                        <p className="admin-items__item-price">Price: ${oldItem.price}</p>
                        <p className="admin-items__item-type">Type: {oldItem.type}</p>
                        <p className="admin-items__item-location">Location: {oldItem.location}</p>
                        <button onClick={() => handleDelete(oldItem._id)} className="admin-items__delete-button">
                            Delete
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AdminItems;
