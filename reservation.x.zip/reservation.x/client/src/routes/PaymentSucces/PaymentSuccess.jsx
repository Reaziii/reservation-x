import React from 'react';
import { Link } from 'react-router-dom';
import './PaymentSuccess.css'; // Assuming you want to style it

const PaymentSuccess = () => {
    return (
        <div className="payment-success">
            <h1>Payment Successful!</h1>
            <p>Thank you for your purchase. Your payment has been processed successfully.</p>
            <Link to="/" className="home-link">Go to Home</Link>
        </div>
    );
};

export default PaymentSuccess;