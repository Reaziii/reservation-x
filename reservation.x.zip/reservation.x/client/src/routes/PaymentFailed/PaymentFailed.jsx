import React from 'react';
import './PaymentFailed.css'; // Assuming you want to add some custom styles

const PaymentFailed = () => {
    const handleRetry = () => {
       window.location.href = "/"
    };

    return (
        <div className="payment-failed-container">
            <h1>Payment Failed</h1>
            <p>We're sorry, but your payment could not be processed. Please try again.</p>
            <button onClick={handleRetry}>Retry Payment</button>
        </div>
    );
};

export default PaymentFailed;