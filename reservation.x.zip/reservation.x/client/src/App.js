import logo from './logo.svg';
import './App.css';
import Home from './routes/Home/Home';

function App() {
  return (
    <Home/>
  );
}

export default App;
