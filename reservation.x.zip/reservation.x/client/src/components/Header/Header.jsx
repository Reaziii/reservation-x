import React from "react";
import "./Header.css";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header className="header">
      <div className="logo">airin</div>
      <nav className="nav">
        <ul>
          <li>
            <a href="/">Home</a>
          </li>
          <li>
            <a href="#about">About</a>
          </li>
          <li>
            <a href="#services">Services</a>
          </li>
          <li>
            <Link to="/my-bookings">My Bookings</Link>
          </li>
        </ul>
      </nav>
      {localStorage.getItem("jwttoken") || localStorage.getItem("admintoken") ? (
        <div onClick={()=> {
            localStorage.removeItem('jwttoken')
            localStorage.removeItem('admintoken')
            window.location.href = "/"
        }}>
          <button className="login-button">Logout</button>
        </div>
      ) : (
        <Link to={"/login"}>
          <button className="login-button">Login</button>
        </Link>
      )}
    </header>
  );
};

export default Header;
